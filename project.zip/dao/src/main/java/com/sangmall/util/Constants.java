package com.sangmall.util;

public interface Constants {
	public static String SANG_MALL_IMAGE_SERVER = "http://localhost:8080/sangmall/images";
}
